import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database"

function startFirebase(){
  const firebaseConfig = {
    apiKey: "AIzaSyDzIVxw8r9YHzfFmpq9aUIBTbj16dp87WA",
    authDomain: "solo-project-firebase.firebaseapp.com",
    databaseURL: "https://solo-project-firebase-default-rtdb.firebaseio.com",
    projectId: "solo-project-firebase",
    storageBucket: "solo-project-firebase.appspot.com",
    messagingSenderId: "384002427929",
    appId: "1:384002427929:web:6ef857478f2ad18c60ee88"
  };
  const app = initializeApp(firebaseConfig);
  return getDatabase(app);
}

export default startFirebase;