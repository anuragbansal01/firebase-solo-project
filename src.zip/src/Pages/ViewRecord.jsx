// ViewRecord.jsx

import React, { useEffect, useState } from 'react';
import startFirebase from '../firebase';
import { ref, onValue } from 'firebase/database';
import './ViewRecord.css';

const db = startFirebase();

const ViewRecord = () => {
  const [records, setRecords] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const dataRef = ref(db, 'formData');
      onValue(dataRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const recordsArray = Object.keys(data).map((key) => ({
            id: key,
            ...data[key],
          }));
          setRecords(recordsArray);
          console.log('Number of Records:', recordsArray.length); // Display the number of records in console
        }
      });
    };

    fetchData();
  }, []);

  return (
    <div className='form-body'>
      <h2>View Records</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Date of Birth</th>
            <th>Qualifications</th>
            <th>Resume</th>
            <th>Image</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record) => (
            <tr key={record.id}>
              <td>{record.name}</td>
              <td>{record.address}</td>
              <td>{record.contact}</td>
              <td>{record.email}</td>
              <td>{record.dob}</td>
              <td>
                {record.qualifications.map((qualification, index) => (
                  <div key={index}>{qualification}</div>
                ))}
              </td>
              <td>{record.resume ? 'Yes' : 'No'}</td>
              <td>{record.image ? 'Yes' : 'No'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewRecord;
    