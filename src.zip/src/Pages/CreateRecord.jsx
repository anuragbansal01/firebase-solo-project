import DataForm from "../components/DataForm"

export default function Form(){
    return(
        <>
            <DataForm/>
        </>
    )
}